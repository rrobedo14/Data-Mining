#!/usr/bin/env python
# coding: utf-8

# In[63]:


from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn import svm, datasets
from sklearn.naive_bayes import GaussianNB
from sklearn.inspection import DecisionBoundaryDisplay
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.linear_model import LinearRegression


# In[62]:


pca = PCA(2)
#Step 1: loading the dataset
iris = datasets.load_iris()
#Step 2: transforming the dataset features to reduce dimensions from 4D to 2D
X_transformed = pca.fit_transform(iris.data)
#Step 3: obtaining the true labels of dataset
y = iris.target
#Step 4: splitting the dataset into 15% testing set and 85% training set in a random fashion
X_train, X_test, y_train, y_test = train_test_split(X_transformed, y, test_size=0.15, random_state=23)


# In[64]:


#Step 4: Defining 5 models and fitting them to our training set
models = (
    LinearRegression(),
    svm.LinearSVC(C=1, max_iter=10000),
    svm.SVC(kernel='poly', degree=3, gamma=.1, C=1),
    MLPClassifier(solver='lbfgs', alpha=.5, hidden_layer_sizes=(2,2),activation='logistic', random_state=23),
    GaussianNB(var_smoothing=1e1),
    svm.SVC(kernel="sigmoid", gamma=0.6, C=1),
)
models = (clf.fit(X_train, y_train) for clf in models)

# Step 5: Drawing the plots
titles = ("Linear regression",
    "LinearSVC",
    "SVC w/ poly3.1",
    "NN layer:(2,2)",
    "GaussianNB",
    "SVC w/ Sig.6")
fig, sub = plt.subplots(2, 3)
plt.subplots_adjust(wspace=0.4, hspace=0.7)

X0, X1 = X_train[:, 0], X_train[:, 1]
for clf, title, ax in zip(models, titles, sub.flatten()):
    disp = DecisionBoundaryDisplay.from_estimator(
        clf,
        X_train,
        response_method="predict",
        cmap=plt.cm.coolwarm,
        alpha=0.8,
        ax=ax,
        xlabel='PCA.f0',
        ylabel='PCA.f1'
    )
    ax.scatter(X0, X1, c=y_train, cmap=plt.cm.coolwarm, s=20, edgecolors="k")
    ax.set_xticks(())
    ax.set_yticks(())
    ax.set_title(title+'\nscore: '+str(100*round(clf.score(X_test,y_test),3))+'%')#

plt.show()


# In[97]:


########## Part 2 Compare with Degrees 3, 5, 7 ###########

models = (
    svm.SVC(kernel='poly', degree=3, gamma=.3, C=1),
    svm.SVC(kernel='poly', degree=3, gamma=.5, C=1),
    
    svm.SVC(kernel='poly', degree=5, gamma=.3, C=1),
    svm.SVC(kernel='poly', degree=5, gamma=.5, C=1),
    
    svm.SVC(kernel='poly', degree=7, gamma=.3, C=1),
    svm.SVC(kernel='poly', degree=7, gamma=.5, C=1),
)
models = (clf.fit(X_train, y_train) for clf in models)

titles = (
    "SVC w/ poly3.3",
    "SVC w/ poly3.5",
    "SVC w/ poly5.3",
    "SVC w/ poly5.5",
    "SVC w/ poly7.3",
    "SVC w/ poly7.5")

fig, sub = plt.subplots(2, 3)
plt.subplots_adjust(wspace=0.4, hspace=0.7)

X0, X1 = X_train[:, 0], X_train[:, 1]
for clf, title, ax in zip(models, titles, sub.flatten()):
    disp = DecisionBoundaryDisplay.from_estimator(
        clf,
        X_train,
        response_method="predict",
        cmap=plt.cm.coolwarm,
        alpha=0.8,
        ax=ax,
        xlabel='PCA.f0',
        ylabel='PCA.f1'
    )
    ax.scatter(X0, X1, c=y_train, cmap=plt.cm.coolwarm, s=20, edgecolors="k")
    ax.set_xticks(())
    ax.set_yticks(())
    ax.set_title(title+'\nscore: '+str(100*round(clf.score(X_test,y_test),3))+'%')#

plt.show()


# In[103]:


######## Part 3 Gaussian Comparison #########

models = (
    LinearRegression(),
    svm.LinearSVC(C=1, max_iter=10000),
    GaussianNB(var_smoothing=2e1),
    GaussianNB(var_smoothing=1e1),
    GaussianNB(var_smoothing=1e0),
    GaussianNB(var_smoothing=1e-1),
)
models = (clf.fit(X_train, y_train) for clf in models)

titles = (
    "Linear regression",
    "LinearSVC",
    "GaussianNB 2e1",
    "GaussianNB 1e1",
    "GaussianNB 1e0",
    "GaussianNB 1e-1")

fig, sub = plt.subplots(2, 3)
plt.subplots_adjust(wspace=0.4, hspace=0.7)

X0, X1 = X_train[:, 0], X_train[:, 1]
for clf, title, ax in zip(models, titles, sub.flatten()):
    disp = DecisionBoundaryDisplay.from_estimator(
        clf,
        X_train,
        response_method="predict",
        cmap=plt.cm.coolwarm,
        alpha=0.8,
        ax=ax,
        xlabel='PCA.f0',
        ylabel='PCA.f1'
    )
    ax.scatter(X0, X1, c=y_train, cmap=plt.cm.coolwarm, s=20, edgecolors="k")
    ax.set_xticks(())
    ax.set_yticks(())
    ax.set_title(title+'\nscore: '+str(100*round(clf.score(X_test,y_test),3))+'%')#

plt.show()


# In[111]:


######## Part 4 Kernels Sigmoid, RFB ########

models = (
    
    svm.SVC(kernel='sigmoid', degree=3, gamma=1e-1, C=1),
    svm.SVC(kernel='sigmoid', degree=3, gamma=1e0 , C=1),
    svm.SVC(kernel='sigmoid', degree=3, gamma=1e2 , C=1),
    
    svm.SVC(kernel='rbf', degree=3, gamma=1e-1, C=1),
    svm.SVC(kernel='rbf', degree=3, gamma=1e0 , C=1),
    svm.SVC(kernel='rbf', degree=3, gamma=1e2 , C=1),
)
models = (clf.fit(X_train, y_train) for clf in models)

titles = (
    "SVC w/ Sig.1e-1",
    "SVC w/ Sig.1e0",
    "SVC w/ Sig.1e2",
    "SVC w/ RBF.1e-1",
    "SVC w/ RBF.1e0",
    "SVC w/ RBF.1e2",
)

fig, sub = plt.subplots(2, 3)
plt.subplots_adjust(wspace=0.4, hspace=0.7)

X0, X1 = X_train[:, 0], X_train[:, 1]
for clf, title, ax in zip(models, titles, sub.flatten()):
    disp = DecisionBoundaryDisplay.from_estimator(
        clf,
        X_train,
        response_method="predict",
        cmap=plt.cm.coolwarm,
        alpha=0.8,
        ax=ax,
        xlabel='PCA.f0',
        ylabel='PCA.f1'
    )
    ax.scatter(X0, X1, c=y_train, cmap=plt.cm.coolwarm, s=20, edgecolors="k")
    ax.set_xticks(())
    ax.set_yticks(())
    ax.set_title(title+'\nscore: '+str(100*round(clf.score(X_test,y_test),3))+'%')#

plt.show()


# In[148]:


######### Part 5 Neural Network MLP Classifiers Comparison ##########

models = (
    
    MLPClassifier(solver='adam', alpha=1e-4, hidden_layer_sizes=(30,30),activation='logistic', random_state=23),
    MLPClassifier(solver='adam', alpha=1e-4, hidden_layer_sizes=(30,30),activation='relu'    , random_state=23),
    MLPClassifier(solver='adam', alpha=1e-4, hidden_layer_sizes=(10,5) ,activation='logistic', random_state=23),
    MLPClassifier(solver='adam', alpha=1e-4, hidden_layer_sizes=(10,5) ,activation='relu'    , random_state=23),
    
    MLPClassifier(solver='lbfgs', alpha=1e-4, hidden_layer_sizes=(30,30),activation='logistic', random_state=23),
    MLPClassifier(solver='lbfgs', alpha=1e-4, hidden_layer_sizes=(30,30),activation='relu'    , random_state=23),
    MLPClassifier(solver='lbfgs', alpha=1e-4, hidden_layer_sizes=(10,5) ,activation='logistic', random_state=23),
    MLPClassifier(solver='lbfgs', alpha=1e-4, hidden_layer_sizes=(10,5) ,activation='relu'    , random_state=23),
    
)

models = (clf.fit(X_train, y_train) for clf in models)

titles = (
    "AD log:(30,30)",
    "AD rel:(30,30)",
    "AD log:(10,5)" ,
    "AD rel:(10,5)" ,
    "NN log:(30,30)",
    "NN rel:(30,30)",
    "NN log:(10,5)" ,
    "NN rel:(10,5)" ,
)

fig, sub = plt.subplots(2, 4)
plt.subplots_adjust(wspace=0.4, hspace=0.7)

X0, X1 = X_train[:, 0], X_train[:, 1]
for clf, title, ax in zip(models, titles, sub.flatten()):
    disp = DecisionBoundaryDisplay.from_estimator(
        clf,
        X_train,
        response_method="predict",
        cmap=plt.cm.coolwarm,
        alpha=.8,
        ax=ax,
        xlabel='PCA.f0',
        ylabel='PCA.f1'
    )
    ax.scatter(X0, X1, c=y_train, cmap=plt.cm.coolwarm, s=20, edgecolors="k")
    ax.set_xticks(())
    ax.set_yticks(())
    ax.set_title(title+'\nscore: '+str(100*round(clf.score(X_test,y_test),3))+'%')#

plt.show()


# In[ ]:




