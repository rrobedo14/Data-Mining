#!/usr/bin/env python
# coding: utf-8

# In[244]:


import pandas as pd
import sklearn
import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.datasets import load_breast_cancer
from sklearn.datasets import load_iris
from sklearn.cluster import AgglomerativeClustering
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.cluster import DBSCAN


# In[245]:


#data = load_breast_cancer()
#data_df = pd.DataFrame(data = data.data,
#                    columns = data.feature_names)
#data_df.head(20)


# In[246]:


#########Part 1 ########

data = load_breast_cancer().data
pca = PCA(2)
df = pca.fit_transform(data)

kmeans = KMeans(n_clusters = 10)
label = kmeans.fit_predict(df)

for i in range(10):plt.scatter(df[label == i , 0] , df[label == i , 1] , label = i)
plt.legend()
plt.show()


# In[247]:


#data = load_digits()
#data_df = pd.DataFrame(data = data.data,
#                    columns = data.feature_names)
#data_df.head(20)


# In[257]:


####Part 2 ######

data = load_digits().data
pca = PCA(2)
df = pca.fit_transform(data)

dbscan = DBSCAN(min_samples = 10, eps = 1.5)
label = dbscan.fit_predict(df)

for i in range(23):plt.scatter(df[label == i , 0] , df[label == i , 1] , label = i)
plt.legend()
plt.show()


# In[254]:


#data = load_iris()
#data_df = pd.DataFrame(data = data.data,
#                   columns = data.feature_names)
#data_df.head(20)


# In[259]:


####Part 3 ####
data = load_iris().data
pca = PCA(2)
df = pca.fit_transform(data)

dbscan = AgglomerativeClustering(n_clusters = 5)
label = dbscan.fit_predict(df)

for i in range(6):plt.scatter(df[label == i , 0] , df[label == i , 1] , label = i)
plt.legend()
plt.show()


# In[262]:


####Part 4 ######
data = load_breast_cancer().data
pca = PCA(2)
df = pca.fit_transform(data)

kmeans = KMeans(n_clusters = 20)
label = kmeans.fit_predict(df)

for i in range(21):plt.scatter(df[label == i , 0] , df[label == i , 1] , label = i)
plt.legend()
plt.show()

data = load_iris().data
pca = PCA(2)
df = pca.fit_transform(data)

dbscan = AgglomerativeClustering(n_clusters = 20)
label = dbscan.fit_predict(df)

for i in range(21):plt.scatter(df[label == i , 0] , df[label == i , 1] , label = i)
plt.legend()


# In[ ]:




