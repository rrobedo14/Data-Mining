#!/usr/bin/env python
# coding: utf-8

# In[170]:


import pandas as pd
from mlxtend.frequent_patterns import apriori, association_rules
import matplotlib.pyplot as plt
import numpy as np

df = pd.read_csv("online_retail_II.csv")
#print(df)


# In[171]:


#print(df.Country.unique())
dropped_na_df = df.dropna()
i = df['StockCode'].astype(str).str.isdigit()
j = df['Invoice'].astype(str).str.isdigit()
df = df[i&j]
#print(df)

df = df[df['Price'] > 10] 
#print(df)


# In[172]:


#print(df.Country.unique())

df= df[(df.Country == "United Kingdom") | (df.Country == "Italy") | (df.Country == "France") | (df.Country == "Germany")|
            (df.Country == "Norway") | (df.Country == "Finland") | (df.Country == "Austria") | (df.Country == "Belgium")|
            (df.Country == "European Community") | (df.Country == "Cyprus") | (df.Country == "Greece") | (df.Country == "Iceland")|
            (df.Country == "Malta") | (df.Country == "Netherlands") | (df.Country == "Portugal") | (df.Country == "Spain")|
            (df.Country == "Sweden") | (df.Country == "Switzerland")]
#print(df)


# In[173]:


#df.loc[~(df==0).all(axis=1)]


# In[174]:


df['Description'] = df['Description'].str.strip()
print (df)


# In[175]:


basket_France = (df[df['Country'] =="France"]
          .groupby(['Invoice', 'Description'])['Quantity']
          .sum().unstack().reset_index().fillna(0)
          .set_index('Invoice'))
  
# Transactions done in the United Kingdom
#basket_UK = (data[data['Country'] =="United Kingdom"]
 #         .groupby(['InvoiceNo', 'Description'])['Quantity']
  #        .sum().unstack().reset_index().fillna(0)
   #       .set_index('InvoiceNo'))
  
# Transactions done in Portugal
#basket_Por = (data[data['Country'] =="Portugal"]
 #         .groupby(['InvoiceNo', 'Description'])['Quantity']
  #        .sum().unstack().reset_index().fillna(0)
   #       .set_index('InvoiceNo'))
  
#basket_Sweden = (data[data['Country'] =="Sweden"]
 #         .groupby(['InvoiceNo', 'Description'])['Quantity']
  #        .sum().unstack().reset_index().fillna(0)
   #       .set_index('InvoiceNo'))
#print(basket_France)


# In[176]:



def hot_encode(x):
    if(x<= 0):
        return 0
    if(x>= 1):
        return 1
    
basket_encoded = basket_France.applymap(hot_encode)
basket_France = basket_encoded
#print(basket_France)


# In[177]:


frq_items = apriori(basket_France, min_support = 0.01, use_colnames = True)

rules = association_rules(frq_items, metric ="lift", min_threshold = 1)
rules = rules.sort_values(['confidence', 'lift'], ascending =[False, False])
#print(rules.head())


# In[178]:


rules_10 = rules[rules['confidence'] > .1]
#print(rules_10)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




