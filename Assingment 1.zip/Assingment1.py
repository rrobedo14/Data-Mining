#!/usr/bin/env python
# coding: utf-8

# In[25]:


#1. Read Data into Pandas


# In[41]:


import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv("titanic.csv")
#print(df)


# In[27]:


#2 Remove all empty cell and count


# In[28]:


dropped_na_df = df.dropna()
#print(f"All observations/rows : {len(df)}")
print(f"Removed observations/rows : {len(df) - len(dropped_na_df)}")


# In[29]:


#3 Using deck to remove empty cells


# In[30]:


deck_df = df.drop(columns=['deck'])
deck_df = deck_df.dropna()
print(f"Removed observations/rows : {len(df) - len(new_df)}")


# In[31]:


#4 Histograms and Boxplots


# In[32]:


# Histograms
fare_mean = new_df['fare'].mean()
fare_std = new_df['fare'].std()
filtered_df = new_df[(new_df['fare']<=fare_mean + 2*fare_std) & (new_df['fare']>=fare_mean - 2*fare_std)]

f, ax = plt.subplots(1, 2, figsize=[15,5])
f.suptitle('Fare Histogram')

ax[0].hist(new_df['fare'], density=True, bins=30)
ax[0].set(ylabel='Probability', xlabel='Fare', title = 'With Extreme Fares')

ax[1].hist(filtered_df['fare'], density=True, bins=30)
ax[1].set(ylabel='Probability', xlabel='Fare', title = 'Without Extreme Fares')

plt.show()


# Boxplots
f, ax = plt.subplots(1, 2, figsize=[20,10])
f.suptitle('Fare Boxplot')
new_df.boxplot(column = ['fare'], ax=ax[0])
ax[0].set(ylabel='Fare', title = 'With Extreme Fares')

filtered_df.boxplot(column = ['fare'], ax=ax[1])
ax[1].set(ylabel='Fare', title = 'Without Extreme Fares')

plt.show()


# In[33]:


#5 Histogram and Boxplots for Age or Fare Outliers


# In[39]:


#Histogram
fare_25_quantile = new_df['fare'].quantile(0.25)
fare_75_quantile = new_df['fare'].quantile(0.75)
fare_IQR = fare_75_quantile - fare_25_quantile
fare_low_outlier = fare_25_quantile - 1.5 * fare_IQR
fare_high_outlier = fare_75_quantile + 1.5 * fare_IQR

age_25_quantile = new_df['age'].quantile(0.25)
age_75_quantile = new_df['age'].quantile(0.75)
age_IQR = age_75_quantile - age_25_quantile

age_low_outlier = age_25_quantile - 1.5 * age_IQR
age_high_outlier = age_75_quantile + 1.5 * age_IQR

outlier_filtered_df = new_df[(new_df['fare']<=fare_high_outlier) &
                             (new_df['fare']>=fare_low_outlier) &
                             (new_df['age']<=age_high_outlier) &
                             (new_df['age']>=age_low_outlier)]


f, ax = plt.subplots(1, 2, figsize=[15,5])
f.suptitle('Fare Histogram(Without Outliers)')
ax[0].hist(new_df['fare'], density=True, bins=30)
ax[0].set(ylabel='Probability', xlabel='Fare', title = 'With Outlier fares and age')

ax[1].hist(outlier_filtered_df['fare'], density=True, bins=30)
ax[1].set(ylabel='Probability', xlabel='=Fare', title = 'Without outlier fares and age')

plt.show()

#Boxplots
f, ax = plt.subplots(1, 2, figsize=[15,5])
f.suptitle('Fare Boxplot(With Outliers)')

new_df.boxplot(column = ['fare'], ax=ax[0])
ax[0].set(ylabel='fare', title = 'With outliers fares and age')

outlier_filtered_df.boxplot(column = ['fare'], ax=ax[1])
ax[1].set(ylabel='fare', title = 'Without outliers fares and age')

plt.show()


# In[38]:


# Comparison
f, ax = plt.subplots(1, 3, figsize=[20,10])
f.suptitle('Histogram for fare (Histogram Comparison)')
ax[0].hist(new_df['fare'], density=True, bins=30)
ax[0].set(ylabel='Probability', xlabel='Fare', title = 'Before filtering')


ax[1].hist(filtered_df['fare'], density=True, bins=30)
ax[1].set(ylabel='Probability', xlabel='fare', title = 'After removing extreme fares ')

# plot histogram for 'fare' column after removing the outlier fares and age
ax[2].hist(outlier_filtered_df['fare'], density=True, bins=30)
ax[2].set(ylabel='Probability', xlabel='fare', title = 'After removing the outlier fares and age')

# show plots
plt.show()


# In[40]:



# Comparison of plots

f, ax = plt.subplots(1, 3, figsize=[15,5])
f.suptitle('Boxplot for fare (Comparison of Charts')

new_df.boxplot(column = ['fare'], ax=ax[0])
ax[0].set(ylabel='fare', title = 'Before filtering')

filtered_df.boxplot(column = ['fare'], ax=ax[1])
ax[1].set(ylabel='fare', title = 'After removing the extreme fares')

outlier_filtered_df.boxplot(column = ['fare'], ax=ax[2])
ax[2].set(ylabel='fare', title = 'After removing the outlier fares and age')

# show plots
plt.show()


# In[ ]:




